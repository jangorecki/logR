# logR 2.1.3 (devel)

* `logR` gets `lazy` argument default TRUE, that will allow deparsing expression easy without substitution in parent calls.
* `logR` gets `boolean` argument to return logical value of `status` field.
* `logR_dump` function to dump all logs table.
* `logR_connection` with default to docker postgres env vars.
* more robust CI tests